Pour réaliser l’exercice : 
- Utilisez les deux fichiers texte (.txt) comme point de départ pour réaliser 2 pages HTML liées entre elles : la page index.html (basée sur le contenu texte de index.txt) et la page recette.html (basée sur le contenu texte de recette.txt). 
- Dans index.html faites un lien depuis la recette “Toast chèvre…” qui permette de cliquer sur l’image et le titre de la recette
- Dans la page recette.html, faites le lien sur le texte : “Revenir à la liste de mes recettes”
- Vos pages HTML doivent être “valide” (avec toute la structure) et être identique visuellement aux deux fichiers PGN index.png et recette.png présents dans le dossier “a_realiser”.
- Le fichier recette_v2.png dans le dossier "a_realiser" est un modèle pour la deuxième partie de l'exercice (lorsque l'on aura vu les tables et formulaires)